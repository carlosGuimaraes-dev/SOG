# MEMORY — CTO

> Arquivo dinâmico. Consulte antes de qualquer planejamento para manter
> consistência arquitetural entre sessões.

---

## Stack atual do projeto

<!-- Atualize assim que identificar a stack.
- **Linguagem**: ...
- **Framework**: ...
- **Banco**: ...
- **Autenticação**: ...
- **Testes**: ...
- **Infra**: ...
-->

_Stack não mapeada ainda._

---

## Decisões arquiteturais

<!-- Nunca delete — apenas adicione.
- **YYYY-MM-DD | Tema**
  Decidido: ...
  Alternativas: ...
  Motivo: ...
  Reversibilidade: alta / média / baixa
-->

_Nenhuma decisão registrada ainda._

---

## Padrões do projeto

<!-- Convenções reais do codebase.
- Imports: absolutos a partir de src/
- Schemas em schemas/, modelos em models/
- Variáveis de ambiente via dotenv, nunca hardcoded
-->

_Nenhum padrão registrado ainda._

---

## Débitos técnicos identificados

<!-- Problemas conhecidos não resolvidos agora.
- `auth/utils.py` linha 47: token sem rotação de chave — risco de segurança.
-->

_Nenhum débito registrado ainda._

---

## Planos executados (índice)

<!-- - `.kimi/plans/auth-jwt.md` — executado, aprovado (2024-01-20) -->

_Nenhum plano registrado ainda._
