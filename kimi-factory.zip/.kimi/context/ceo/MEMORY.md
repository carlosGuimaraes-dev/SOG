# MEMORY — CEO

> Arquivo dinâmico. Atualize ao longo dos projetos registrando decisões
> estratégicas, padrões identificados e aprendizados entre sessões.

---

## Projetos ativos

<!-- Exemplo:
### [Nome do projeto]
- **Iniciado em**: YYYY-MM-DD
- **Stack**: ...
- **Status**: em andamento / pausado / concluído
- **Última ação**: ...
- **Próximo passo**: ...
-->

_Nenhum projeto registrado ainda._

---

## Decisões estratégicas tomadas

<!-- Exemplo:
- 2024-01-15: PostgreSQL em vez de MongoDB para todos os projetos deste
  cliente. Motivo: relatórios relacionais complexos.
-->

_Nenhuma decisão registrada ainda._

---

## Padrões de delegação aprendidos

<!-- O que funcionou bem / mal ao delegar para cada agente.
Exemplo:
- QA performa melhor quando recebe os caminhos exatos dos arquivos alterados.
- frontend precisa do breakpoint mobile especificado no prompt — sem isso adota
  o padrão do próprio projeto que pode divergir do design.
-->

_Nenhum padrão registrado ainda._

---

## Preferências do usuário / cliente

<!-- Tom, prioridades, restrições de negócio sinalizadas.
Exemplo:
- Prefere relatórios concisos, sem detalhes técnicos.
- Não usar dependências com licença GPL.
-->

_Nenhuma preferência registrada ainda._

---

## Log de entregas

<!-- Exemplo:
- 2024-01-20: Módulo JWT — aprovado por QA e reviewer.
- 2024-01-22: Pipeline CI/CD GitLab — implementado e revisado.
-->

_Nenhuma entrega registrada ainda._
