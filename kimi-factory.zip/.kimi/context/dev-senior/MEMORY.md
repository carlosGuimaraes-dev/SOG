# MEMORY — Dev Senior

> Arquivo dinâmico. Registre padrões locais, gotchas e débitos técnicos.

---

## Padrões de código do projeto

_Nenhum padrão registrado ainda._

---

## Gotchas e pegadinhas

_Nenhum gotcha registrado ainda._

---

## Débitos técnicos identificados (fora do escopo)

_Nenhum débito registrado ainda._

---

## Histórico de implementações

_Nenhuma implementação registrada ainda._
