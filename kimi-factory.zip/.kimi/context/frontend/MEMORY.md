# MEMORY — Frontend Engineer

> Arquivo dinâmico. Registre padrões de UI, design system e gotchas do projeto.

---

## Stack de frontend

<!-- Framework, lib de UI, estilização, estado, testes, build tool -->
_Não mapeada ainda._

---

## Design system e tokens

<!-- Cores, tipografia, espaçamento, breakpoints.
Ex: primary=#1a73e8, font=Inter, breakpoints: sm=640 md=768 lg=1024 xl=1280
-->
_Não documentado ainda._

---

## Componentes reutilizáveis mapeados

<!-- Componentes que já existem e podem ser reaproveitados.
Ex: Button (src/components/ui/Button.tsx) — variantes: primary, secondary, ghost
-->
_Nenhum mapeado ainda._

---

## Padrões de código de UI

<!-- Convenções reais encontradas no codebase.
Ex: Estado global via Zustand. Fetching via react-query. Formulários com react-hook-form.
-->
_Nenhum padrão registrado ainda._

---

## Gotchas de CSS / framework

<!-- Problemas não óbvios encontrados.
Ex: O componente Modal tem z-index conflitando com o header sticky em mobile.
-->
_Nenhum gotcha registrado ainda._

---

## Débitos de UI identificados

<!-- Problemas fora do escopo atual.
Ex: Página de perfil sem estado de loading — exibe dados anteriores durante refetch.
-->
_Nenhum débito registrado ainda._

---

## Histórico de implementações

_Nenhuma implementação registrada ainda._
