# MEMORY — QA Engineer

> Arquivo dinâmico. Registre configuração do ambiente de testes, padrões
> de bugs recorrentes e áreas de risco mapeadas no projeto.

---

## Configuração do ambiente de testes

<!-- Como rodar os testes neste projeto.
Ex:
- Comando: `pytest tests/ -v --cov=src`
- Requer: .env.test com banco de teste separado
- Fixtures: db_session (conftest.py), auth_client (conftest.py)
- Mocks: serviço de email mockado por padrão em tests/
-->
_Não configurado ainda._

---

## Padrões de bugs recorrentes

<!-- Tipos de problemas que aparecem com frequência.
Ex:
- Validações retornam 500 em vez de 400 quando campo é null
- Endpoints de listagem não aplicam filtro de tenant em queries aninhadas
-->
_Nenhum padrão registrado ainda._

---

## Áreas de risco identificadas

<!-- Partes do sistema com mais bugs ou menos cobertura.
Ex:
- Módulo de notificações: cobertura < 30%
- Lógica de permissões: complexa, muitos edge cases
-->
_Nenhuma área de risco registrada ainda._

---

## Histórico de validações

<!-- Ex:
- 2024-01-20: auth/jwt.py — APROVADO (cobertura 87%)
- 2024-01-22: routers/users.py — REPROVADO (Bug #3: DELETE sem verificação de owner)
-->
_Nenhuma validação registrada ainda._
