# MEMORY — Docs Writer

> Arquivo dinâmico. Registre convenções de documentação, mapa de docs
> existentes e lacunas identificadas.

---

## Convenções de documentação do projeto

<!-- Ex:
- Idioma: português para docs internas, inglês para docs públicas
- Formato de API: Markdown com exemplos cURL
- Estilo de changelog: Keep a Changelog
- Docstrings: Google style (Args, Returns, Raises, Example)
-->
_Nenhuma convenção registrada ainda._

---

## Mapa de documentação existente

<!-- O que existe, onde está e quando foi atualizado.
Ex:
- README.md — visão geral + instalação (atualizado 2024-01-20)
- docs/api.md — endpoints REST (desatualizado — não cobre /auth/token)
- CHANGELOG.md — parado na v0.3.0
-->
_Nenhum documento mapeado ainda._

---

## Lacunas de documentação identificadas

<!-- Partes do sistema sem documentação ou com doc desatualizada.
Ex:
- Módulo notifications/ sem README nem docstrings
- Variável SMTP_PORT usada mas não listada no .env.example
-->
_Nenhuma lacuna registrada ainda._

---

## Histórico de documentações produzidas

<!-- Ex:
- 2024-01-20: README.md — seção de instalação e configuração
- 2024-01-22: docs/api.md — endpoints de autenticação JWT
-->
_Nenhuma documentação registrada ainda._
