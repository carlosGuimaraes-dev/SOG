# MEMORY — DevOps Engineer

> Arquivo dinâmico. Registre plataforma, pipelines, secrets e procedimentos.

---

## Plataforma de CI/CD

<!-- GitHub Actions / GitLab CI / outro -->
_Não identificada ainda._

---

## Repositório e branches

<!-- Organização de branches, branch protection rules, política de PR.
Ex: main (protegida, requer PR + CI verde + 1 aprovação)
    develop (integração), feature/* (desenvolvimento)
-->
_Não documentado ainda._

---

## Pipelines existentes

<!-- Nome, arquivo, propósito e status de cada pipeline.
Ex: .github/workflows/ci.yml — lint + test em PRs (ativo)
    .github/workflows/deploy.yml — deploy em prod via tag (ativo)
-->
_Nenhum mapeado ainda._

---

## Secrets configurados

<!-- Nomes dos secrets (nunca os valores) e onde estão configurados.
Ex: AWS_ACCESS_KEY_ID — GitHub Secrets (repo level)
    DATABASE_URL — GitLab CI Variables (masked, protected)
-->
_Nenhum registrado ainda._

---

## Ambientes

<!-- Staging, produção, desenvolvimento e suas configurações.
Ex: staging: ECS cluster us-east-1, deploy automático em merge para develop
    production: ECS cluster us-east-1, deploy manual via tag vX.Y.Z
-->
_Nenhum ambiente documentado ainda._

---

## Procedimentos de deploy e rollback

<!-- Como fazer deploy e como reverter.
Ex: Deploy: criar tag vX.Y.Z → pipeline deploy.yml dispara automaticamente
    Rollback: re-tag da versão anterior → mesmo pipeline
    Tempo médio: 8 minutos
-->
_Nenhum procedimento documentado ainda._

---

## Gotchas de infra identificados

<!-- Problemas não óbvios encontrados.
Ex: O runner do GitLab não tem acesso à VPC — deploys precisam de VPN tunnel.
-->
_Nenhum gotcha registrado ainda._

---

## Débitos de infra identificados

_Nenhum débito registrado ainda._

---

## Histórico de mudanças de infra

_Nenhuma mudança registrada ainda._
